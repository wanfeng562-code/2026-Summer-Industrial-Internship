package com.alibaba.spring01;

import com.alibaba.spring01.entity.Person;
import com.alibaba.spring01.entity.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest   //SpringBoot的测试类 启动spring boot容器
class Spring01ApplicationTests {

    @Autowired   //依赖注入
    private Student student;

    @Autowired   //依赖注入
    private Person person;

    @Test
    public void test01() {

        student.study();
        System.out.println(person);
    }

}
