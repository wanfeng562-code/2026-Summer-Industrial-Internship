package com.alibaba.spring01.config;

import com.alibaba.spring01.entity.Person;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration  //说明当前类是配置类
public class MyConfig {

//    @Bean  //把当前方法返回的对象放入spring boot 容器中
//    public Person getPerson(){
//        return new Person("李雷", 21, "湖北武汉");
//    }
}
