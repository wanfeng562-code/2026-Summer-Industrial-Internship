package com.alibaba.spring01.entity;

import org.springframework.stereotype.Component;

@Component   //把当前类的实例放入spring boot容器中
public class Student {

    public void study(){
        System.out.println("学生努力学习");
    }
}
