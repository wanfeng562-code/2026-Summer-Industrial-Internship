package com.alibaba.spring01.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data    //生成get/set方法
@ToString   //生成toString方法
@AllArgsConstructor   //生成全参的构造函数
@NoArgsConstructor   //生成无参的构造函数
@Component   //将这个类交给spring管理
public class Person {

    @Value("韩梅梅")
    private String name;

    @Value("18")
    private Integer age;

    @Value("北京")
    private String address;

}
