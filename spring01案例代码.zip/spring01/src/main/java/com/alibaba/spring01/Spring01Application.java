package com.alibaba.spring01;

import com.alibaba.spring01.entity.Person;
import com.alibaba.spring01.entity.Student;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Spring01Application {

    public static void main(String[] args) {

        //初始化，得到spring boot容器对象
        ConfigurableApplicationContext ctx = SpringApplication.run(Spring01Application.class, args);

        //从容器中获取对象
        Student student = ctx.getBean(Student.class);
        student.study();

        Person person = ctx.getBean(Person.class);
        System.out.println(person);
    }

}
