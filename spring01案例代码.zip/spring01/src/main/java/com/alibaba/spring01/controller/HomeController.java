package com.alibaba.spring01.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController   //返回数据对象  控制层  加入spring boot容器
public class HomeController {


    @GetMapping("/")
    public String home(){

        return "Hello, Spring Boot3";
    }
}
