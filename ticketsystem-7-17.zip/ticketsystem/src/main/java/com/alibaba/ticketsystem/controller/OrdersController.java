package com.alibaba.ticketsystem.controller;

import com.alibaba.ticketsystem.entity.Orders;
import com.alibaba.ticketsystem.service.OrdersService;
import com.alibaba.ticketsystem.utils.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 订单表 控制层
 * </p>
 *
 * @author YanTao
 * @since 2026-07-17
 */
@RestController    //返回数据对象
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    @GetMapping("/orders/{page}/{pageSize}")
    public R<?> pageOrders(@PathVariable("page") Integer page,
                                      @PathVariable("pageSize") Integer pageSize){
        Page<Orders> po = ordersService.pageOrders(page, pageSize);
        return R.success("订单分页查询成功", po);
    }

}
